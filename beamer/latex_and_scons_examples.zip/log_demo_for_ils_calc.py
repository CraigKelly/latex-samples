import pylab
import math
import itertools

chain = itertools.chain

E = math.e
ln = math.log

tests = [1, 10, 100, 1000, 2000, 3000, 4000, 5000]

def oldf(v):
    return v * 0.48
    
def newf(v):
    v2 = oldf(v)
    if v2 > 100.0:
        v2 = v2 / (ln(v) * 0.8)
    return v2

def expf(v):
    r = v / 1000.0
    m = ln(1.0 + r) / r #=1 as x approaches 0
    return v * (0.48 * m)


def main():
    def dump_one(t):    
        print "%12.1f %12.1f %12.1f %12.1f" % (t, oldf(t), newf(t), expf(t))
    for t in tests:
        dump_one(float(t))
   
    def dofig(title, make_fig, xs):
        make_fig()
        pylab.title(title)
        pylab.grid(True)
        def plotone(func):
            pylab.plot(xs, [func(i) for i in xs])
        plotone(oldf)
        #plotone(newf)
        plotone(expf)
        #pylab.legend(["Old", "Interim", "New"], "upper left")
        pylab.legend(["Old", "New"], "upper left")

    def sep_figs():
        pylab.figure(dpi=75, figsize=(14,9))
    
    dofig("Small Range",  sep_figs, range(1, 250, 1))
    dofig("Medium Range", sep_figs, range(1, 1000, 5))
    dofig("Large Range",  sep_figs, range(1, 15000, 100))
    
    class _one_fig(object):
        def __init__(self):
            self.count = 0
        def one_fig(self):
            f = pylab.figure(4, dpi=75, figsize=(14,9))
            self.count += 1
            sf = f.add_subplot(220 + self.count)
    one_fig = _one_fig().one_fig
    
    dofig("Small Range",  one_fig, range(1, 250, 1))
    dofig("Medium Range", one_fig, range(1, 1000, 5))
    dofig("Large Range",  one_fig, range(1, 15000, 100))
    
    #tab_cols = ("Old", "Interim", "New")
    tab_cols = ("Old", "New")
    tab_rows = []
    tab_cells = []
    for t in tests:
        tab_rows.append(str(t))
        #row_text = [oldf(t), newf(t), expf(t)]
        row_text = [oldf(t), expf(t)]
        tab_cells.append(["%.2f" % i for i in row_text])

    sf = pylab.figure(4).add_subplot(224, frameon=False)
    
    ticks = chain(
        sf.get_xticklabels(), 
        sf.get_yticklabels(), 
        sf.get_xticklines(), 
        sf.get_yticklines()
    )
    for tl in ticks:
        tl.set_visible(False)    
    
    table = sf.table(
        cellText = tab_cells,
        rowLabels = tab_rows,
        colLabels = tab_cols,
        loc='center'
    )
    
    print "Saving qty_formula_graph.pdf"
    pylab.savefig(
        "qty_formula_graph.pdf", 
        orientation='landscape',
        format='pdf'
    )
    
    #pylab.show()
    
   
if __name__ == "__main__":
    main()
